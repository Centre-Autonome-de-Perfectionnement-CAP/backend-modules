<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (Schema::hasColumn('scheduled_courses', 'deleted_at')) {
            return;
        }

        Schema::table('scheduled_courses', function (Blueprint $table) {
            $table->softDeletes(); // Ajoute 'deleted_at'
            //
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('scheduled_courses', function (Blueprint $table) {
            $table->dropSoftDeletes();
            //
        });
    }
};
